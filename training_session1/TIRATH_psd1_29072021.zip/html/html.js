function myFun(){
    var name = ['Tirath','Ankit','Anuj','Sachin'];
    for(i=0 ;i<name.length;i++){
        console.log(name[i]);
        // document.write(name[i]);
    }
}

myFun();

 